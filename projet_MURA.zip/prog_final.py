#!/usr/bin/python
# coding: utf-8
# librairie pour ecran
import time
import RPi.GPIO as GPIO
import subprocess
import os
# librairie pour mqtt
import sys
import paho.mqtt.client as mqtt
# affectation de variables
LCD_RS = 4
LCD_E  = 17
LCD_DATA4 = 18
LCD_DATA5 = 22
LCD_DATA6 = 23
LCD_DATA7 = 24

LCD_WIDTH = 16
LCD_LINE_1 = 0x80
LCD_LINE_2 = 0xC0
LCD_CHR = GPIO.HIGH
LCD_CMD = GPIO.LOW
E_PULSE = 0.0005
E_DELAY = 0.0005

##################
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(18, GPIO.OUT)
GPIO.setup(12, GPIO.OUT)
GPIO.setup(16, GPIO.OUT)

GPIO.setup(25, GPIO.IN)
print(" ")
print("PROGRAMME POUR CONNAITRE LE NIVEAU DE L'EAU DES TOITS TERRASSES")
print(" ")
print(" ")
##################
#variables pour l envoie de mail
Current_State  = 0
Previous_State = 0
##################
def lcd_send_byte(bits, mode):
        GPIO.output(LCD_RS, mode)
        GPIO.output(LCD_DATA4, GPIO.LOW)
        GPIO.output(LCD_DATA5, GPIO.LOW)
        GPIO.output(LCD_DATA6, GPIO.LOW)
        GPIO.output(LCD_DATA7, GPIO.LOW)
        if bits & 0x10 == 0x10:
          GPIO.output(LCD_DATA4, GPIO.HIGH)
        if bits & 0x20 == 0x20:
          GPIO.output(LCD_DATA5, GPIO.HIGH)
        if bits & 0x40 == 0x40:
          GPIO.output(LCD_DATA6, GPIO.HIGH)
        if bits & 0x80 == 0x80:
          GPIO.output(LCD_DATA7, GPIO.HIGH)
        time.sleep(E_DELAY)
        GPIO.output(LCD_E, GPIO.HIGH)
        time.sleep(E_PULSE)
        GPIO.output(LCD_E, GPIO.LOW)
        time.sleep(E_DELAY)
        GPIO.output(LCD_DATA4, GPIO.LOW)
        GPIO.output(LCD_DATA5, GPIO.LOW)
        GPIO.output(LCD_DATA6, GPIO.LOW)
        GPIO.output(LCD_DATA7, GPIO.LOW)
        if bits&0x01==0x01:
          GPIO.output(LCD_DATA4, GPIO.HIGH)
        if bits&0x02==0x02:
          GPIO.output(LCD_DATA5, GPIO.HIGH)
        if bits&0x04==0x04:
          GPIO.output(LCD_DATA6, GPIO.HIGH)
        if bits&0x08==0x08:
          GPIO.output(LCD_DATA7, GPIO.HIGH)
        time.sleep(E_DELAY)
        GPIO.output(LCD_E, GPIO.HIGH)
        time.sleep(E_PULSE)
        GPIO.output(LCD_E, GPIO.LOW)  
        time.sleep(E_DELAY)  
#defiition pour inicialier l ecran led
def display_init():
        lcd_send_byte(0x33, LCD_CMD)
        lcd_send_byte(0x32, LCD_CMD)
        lcd_send_byte(0x28, LCD_CMD)
        lcd_send_byte(0x0C, LCD_CMD)  
        lcd_send_byte(0x06, LCD_CMD)
        lcd_send_byte(0x01, LCD_CMD)  
#definition pour le message lcd de l'ecran
def lcd_message(message):
        message = message.ljust(LCD_WIDTH," ")  
        for i in range(LCD_WIDTH):
          lcd_send_byte(ord(message[i]),LCD_CHR)

if __name__ == '__main__':
        # initialisation
        GPIO.setmode(GPIO.BCM)
        GPIO.setwarnings(False)
        GPIO.setup(LCD_E, GPIO.OUT)
        GPIO.setup(LCD_RS, GPIO.OUT)
        GPIO.setup(LCD_DATA4, GPIO.OUT)
        GPIO.setup(LCD_DATA5, GPIO.OUT)
        GPIO.setup(LCD_DATA6, GPIO.OUT)
        GPIO.setup(LCD_DATA7, GPIO.OUT)

        display_init()

#variable pour le broker et pour se connecter:
SERVEUR = '194.199.227.235'
INTERVAL = 5
next_reading = time.time()
client = mqtt.Client()

#certificats SSL du broker :
client.tls_set(ca_certs="/etc/mosquitto/certs/ca_certificats/ca.crt", 
              certfile="/etc/mosquitto/certs/clientpi/clientpi.crt", 
              keyfile="/etc/mosquitto/certs/clientpi/clientpi.key")
client.tls_insecure_set(True)

#mot de passe et port de mosquitto :
client.username_pw_set(username="projet", password="mdpprojet")
client.connect(SERVEUR,1143)
client.loop_start()

while (True):
	if GPIO.input(25):
        GPIO.output(18,GPIO.LOW)
		a=1
		Current_State  =1
		#Affichage sur le pc
		print("Le niveau de l'eau est élevé !!! ")
		print (" ")
		#mosquitto_pub
		client.publish("test_channel1",1)
		#temps
		next_reading += INTERVAL
                sleep_time = next_reading-time.time()
                if sleep_time > 0:
                	time.sleep(sleep_time)



    else :
		GPIO.output(18,GPIO.HIGH)
		a=0
		Current_State = 0
		print("Le niveau de l'eau est correct. ")
        print(" ")
		client.publish("test_channel1",0)
		time.sleep(1)


    if a==1: #Affiche de l ecran du raspberry
        msg1 = "Le niveau d'eau"
        msg2 = "est élevé !!"
    #Allumer led
        GPIO.output(16,True)

    else :
        msg1 = "Le niveau d'eau"
        msg2 = "est correct."
        GPIO.output(12,True)


	#facon dont le texte doit ếtre affiché
    for i in range(len(msg1)):
            lcd_send_byte(LCD_LINE_1, LCD_CMD)
            lcd_message(msg1[:i+1])
            lcd_send_byte(LCD_LINE_2, LCD_CMD)
            lcd_message("")
            time.sleep(0.1)
    for i in range(len(msg2)):
            lcd_send_byte(LCD_LINE_1, LCD_CMD)
            lcd_message(msg1)
            lcd_send_byte(LCD_LINE_2, LCD_CMD)
            lcd_message(msg2[:i+1])
            time.sleep(0.1)

	#limiter le nombre de mail
	if Current_State==1 and Previous_State==0:
	#envoie de mail
		subprocess.call(["/home/pi/Documents/mail/mail.sh"])
                print ("Mail envoyé")
		print (" ")
		print (" ")

		Previous_State=1

  elif Current_State==0 and Previous_State==1:
		Previous_State=0


    #temps avant verif niveau eau
    time.sleep(2)
    #eteindre les led
    GPIO.output(12,False)
    GPIO.output(16,False)



client.loop_stop()
client.disconnect()
